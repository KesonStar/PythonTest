def keson():
    print("Hello Keson!")
if __name__ == "__main__":
    keson()